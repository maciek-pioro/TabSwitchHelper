window.addEventListener('keyup', altHandler)
window.addEventListener('keydown', altHandler)
window.addEventListener('mousemove', altHandler)
browser.runtime.onMessage.addListener(requestHandler)

function requestHandler(request) {
    if(request.altdown) {
        setTitle(request.title)
    }
    else {
        resetTitle()
    }
}

function altHandler(e) {
    if (e.altKey) {
        browser.runtime.sendMessage("altdown")
    }
    else {
        browser.runtime.sendMessage("altup")
    }
}

function setTitle(title) {
    if(tabTitleIsOriginal) {
        originalTabTitle = document.title
        tabTitleIsOriginal = false
    }
    document.title = title
}

function resetTitle() {
    if(tabTitleIsOriginal){
        return
    } 
    document.title = originalTabTitle
    tabTitleIsOriginal = true
        
}

let tabTitleIsOriginal = true
let originalTabTitle = ""

